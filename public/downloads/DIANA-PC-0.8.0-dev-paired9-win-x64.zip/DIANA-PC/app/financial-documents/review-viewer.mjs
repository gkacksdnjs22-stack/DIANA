import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {randomBytes,randomUUID,timingSafeEqual} from 'node:crypto';
import {once} from 'node:events';
import {strictJSON,keys} from './strict-json.mjs';
import {UUID} from '../lib/financial-contract.mjs';
import {reviewFailure} from './saved-review.mjs';

const assets=new Map([['/corrections.mjs',['corrections.mjs','text/javascript; charset=utf-8']],['/annotation-spans.mjs',['annotation-spans.mjs','text/javascript; charset=utf-8']],['/ai-preview.mjs',['ai-preview.mjs','text/javascript; charset=utf-8']],['/',['index.html','text/html; charset=utf-8']],['/review.js',['review.js','text/javascript; charset=utf-8']],['/request-records.mjs',['request-records.mjs','text/javascript; charset=utf-8']],['/local-review.mjs',['local-review.mjs','text/javascript; charset=utf-8']],['/registration.mjs',['registration.mjs','text/javascript; charset=utf-8']],['/automatic.mjs',['automatic.mjs','text/javascript; charset=utf-8']],['/recheck-view.mjs',['recheck-view.mjs','text/javascript; charset=utf-8']],['/review.css',['review.css','text/css; charset=utf-8']],['/diana-icon.png',['diana-icon.png','image/png']]]);

/** PC loopback UI. Relay credentials never authorize local decisions. */
export async function createReviewViewer({onCommand=null,onRecheck=null,onReadCatalog=null,onRegister=null,onPickFolder=null,onDiscover=null,onConnect=null,onRequestRecords=null}={}){
  const token=randomBytes(32).toString('hex'),jobs=new Map(),busy=new Set();
  let connection={connected:false,checkedAt:null},origin;
  const files=new Map(await Promise.all([...assets].map(async([route,[file,type]])=>[route,{type,bytes:await readFile(new URL('./review-ui/'+file,import.meta.url))}])));
  const server=createServer((req,res)=>{
    const finish=(status,content,type='text/plain; charset=utf-8')=>{res.writeHead(status,{'Content-Type':type});res.end(content);};
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    const site=req.headers['sec-fetch-site'];
    if(req.socket.remoteAddress!=='127.0.0.1'||req.headers.host!==new URL(origin).host||(req.headers.origin&&req.headers.origin!==origin)||(site&&!['none','same-origin'].includes(site)))return finish(403,'LOCAL_VIEW_ONLY');
    let route;try{route=new URL(req.url,origin);}catch{return finish(400,'INVALID_REQUEST');}if(route.search)return finish(404,'NOT_FOUND');
    if(req.method==='GET'&&files.has(route.pathname)){const f=files.get(route.pathname);return finish(200,f.bytes,f.type);}
    const action=req.method==='POST'&&route.pathname==='/api/local-action';
    const catalog=req.method==='GET'&&route.pathname==='/api/local-catalog',registration=req.method==='POST'&&/^\/api\/local-catalog\/(documents|tasks|folders\/select|discover|connect)$/u.test(route.pathname);
    const recording=req.method==='POST'&&route.pathname==='/api/request-records';
    if(!recording&&!action&&!catalog&&!registration&&!(req.method==='GET'&&route.pathname==='/api/view'))return finish(req.method==='GET'?404:405,'NOT_FOUND');
    const actual=Buffer.from(req.headers.authorization||''),expected=Buffer.from('Bearer '+token);
    if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return finish(401,'LOCAL_SESSION_REQUIRED');
    if(recording){
      if(typeof onRequestRecords!=='function')return finish(403,'RECORD_UNAVAILABLE');
      if(req.headers.origin!==origin||!/^application\/json(?:;\s*charset=utf-8)?$/iu.test(req.headers['content-type']||''))return finish(403,'LOCAL_ORIGIN_REQUIRED');
      void(async()=>{try{let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>32768)throw Error();chunks.push(chunk);}
        const body=strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks)));
        const result=await onRequestRecords(body,structuredClone([...jobs.values()].map(j=>({job:j.job?{id:j.job.id,taskId:j.job.taskId,state:j.job.state,action:j.job.action,format:j.job.format}:null,result:j.result?{saved:j.result.saved===true,storageVerified:j.result.storageVerified===true}:null}))));
        finish(200,JSON.stringify(result),'application/json; charset=utf-8');
      }catch(error){const code=/^RECORD_[A-Z_]+$/u.test(error?.code||'')?error.code:'RECORD_FAILED';finish(409,JSON.stringify({ok:false,code}),'application/json; charset=utf-8');}})().catch(()=>{if(!res.headersSent&&!res.destroyed)finish(409,'RECORD_FAILED');});return;
    }
    const registrationEnabled=typeof onReadCatalog==='function'&&typeof onRegister==='function';
    if(catalog||registration){
      if(!registrationEnabled)return finish(403,'LOCAL_REGISTRATION_UNAVAILABLE');
      if(registration&&(req.headers.origin!==origin||!/^application\/json(?:;\s*charset=utf-8)?$/iu.test(req.headers['content-type']||'')))return finish(403,'LOCAL_ORIGIN_REQUIRED');
      void(async()=>{
        try{
          if(catalog)return finish(200,JSON.stringify(await onReadCatalog()),'application/json; charset=utf-8');
          let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>1_600_000)throw Object.assign(Error(),{code:'REGISTRATION_INVALID'});chunks.push(chunk);}
          const body=strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks)));
          let result;
          if(route.pathname.endsWith('/folders/select')){if(typeof onPickFolder!=='function')throw Error();result=await onPickFolder(body);}
          else if(route.pathname.endsWith('/discover')){if(typeof onDiscover!=='function')throw Error();result=await onDiscover(body);}
          else if(route.pathname.endsWith('/connect')){if(typeof onConnect!=='function')throw Error();result=await onConnect(body);}
          else result=await onRegister(route.pathname.endsWith('/documents')?'document':'task',body);
          finish(200,JSON.stringify(result),'application/json; charset=utf-8');
        }catch(error){
          const allowed=new Set(['REGISTRATION_BUSY','REGISTRATION_CHANGED','REGISTRATION_CONFLICT','REGISTRATION_INVALID','REGISTRATION_DOCUMENT_INVALID','REGISTRATION_GUIDELINE_INVALID','REGISTRATION_TASK_INVALID','REGISTRATION_REVIEW_INVALID','REGISTRATION_STORAGE_CHANGED','REGISTRATION_BOUNDARY_CHANGED','REGISTRATION_LIMIT','LOCAL_POLICY_CHANGED','DESKTOP_STOPPING','FOLDER_PICKER_UNAVAILABLE','FOLDER_PICKER_FAILED','DISCOVERY_FOLDER_DENIED','DISCOVERY_EXPIRED','DISCOVERY_CHANGED','DISCOVERY_ID_CONFLICT','DISCOVERY_SELECTION_REQUIRED']);
          const code=allowed.has(error?.code)?error.code:'REGISTRATION_FAILED';finish(['REGISTRATION_BUSY','REGISTRATION_CHANGED','REGISTRATION_CONFLICT','LOCAL_POLICY_CHANGED','DESKTOP_STOPPING'].includes(code)?409:400,JSON.stringify({ok:false,code}),'application/json; charset=utf-8');
        }
      })().catch(()=>{if(!res.headersSent&&!res.destroyed)finish(400,'REGISTRATION_FAILED');});return;
    }
    if(!action)return finish(200,JSON.stringify({connection,capabilities:{approve:typeof onCommand==='function',recheck:typeof onRecheck==='function',...(registrationEnabled?{registration:true}:{}),...(typeof onRequestRecords==='function'?{requestRecords:true}:{})},jobs:[...jobs.values()].reverse().map(j=>({...j,busy:busy.has(j.job?.id)}))}),'application/json; charset=utf-8');
    // Every state-changing request needs an actual same-origin JSON fetch as
    // well as the process-local secret. Check state AFTER receiving its body.
    if(req.headers.origin!==origin||!/^application\/json(?:;\s*charset=utf-8)?$/iu.test(req.headers['content-type']||''))return finish(403,'LOCAL_ORIGIN_REQUIRED');
    void(async()=>{
      let body;try{let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>1024)throw Error();chunks.push(chunk);}
        body=strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks)));keys(body,['requestId','viewId','action']);
        if(!UUID.test(body.requestId)||!UUID.test(body.viewId)||!['approve','reject','recheck'].includes(body.action))throw Error();
      }catch{return finish(400,'INVALID_LOCAL_ACTION');}
      const entry=jobs.get(body.requestId),recheck=body.action==='recheck';
      const ready=entry&&!busy.has(body.requestId)&&(recheck?
        entry.resultId===body.viewId&&entry.result?.saved===true&&entry.result?.storageVerified===true&&typeof onRecheck==='function':
        entry.reviewId===body.viewId&&entry.approvalReady===true&&entry.job?.state==='PC_REVIEW_REQUIRED'&&Date.now()<=entry.approvalExpires&&typeof onCommand==='function');
      if(!ready)return finish(409,'LOCAL_ACTION_CHANGED');
      busy.add(body.requestId);
      if(!recheck)jobs.set(body.requestId,{...entry,approvalReady:false});
      try{if(recheck)await onRecheck(body.requestId);else await onCommand(body.action,body.requestId);finish(200,'{"ok":true}','application/json; charset=utf-8');}
      catch(error){
        if(recheck){const failure={...reviewFailure(error),checkedAt:new Date().toISOString()},current=jobs.get(body.requestId);if(current)jobs.set(body.requestId,{...current,recheck:failure});
          finish(409,JSON.stringify({ok:false,code:'SAVED_REVIEW_FAILED',review:failure}),'application/json; charset=utf-8');}
        else finish(409,'LOCAL_ACTION_REJECTED');
      }
      finally{busy.delete(body.requestId);}
    })().catch(()=>{if(!res.headersSent&&!res.destroyed)finish(409,'LOCAL_ACTION_REJECTED');});
  });
  server.requestTimeout=5000;server.headersTimeout=5000;server.keepAliveTimeout=1000;
  server.listen(0,'127.0.0.1');await once(server,'listening');origin='http://127.0.0.1:'+server.address().port;
  return{
    url:origin+'/#view='+token,
    accept(event){
      if(event.type==='connection'){connection={connected:event.connected===true,checkedAt:new Date().toISOString()};return;}
      const id=event.job?.id||event.requestId;if(typeof id!=='string')return;
      const previous=jobs.get(id)||{};
      const next=event.type==='job'?{...previous,job:event.job,label:event.label,phase:event.phase,approvalReady:event.approvalReady,approvalExpires:event.approvalExpires}:
        event.type==='review'?{...previous,documents:event.documents,review:event.review,reviewId:randomUUID()}:
        event.type==='result'?{...previous,result:event.result,resultId:randomUUID()}:
        event.type==='recheck'?{...previous,recheck:event.recheck}:null;
      if(!next)return;jobs.set(id,structuredClone(next));
      while(jobs.size>8)jobs.delete(jobs.keys().next().value);
    },
    async close(){jobs.clear();connection={connected:false,checkedAt:null};server.closeAllConnections();await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));}
  };
}
