// Generated from financial-desktop/version.json. Do not edit.
[assembly: System.Reflection.AssemblyVersion("0.8.0.6")]
[assembly: System.Reflection.AssemblyFileVersion("0.8.0.6")]
[assembly: System.Reflection.AssemblyInformationalVersion("0.8.0-dev-paired6")]
namespace Diana.Desktop { public static class BuildVersion {
    public const string ProductVersion = "0.8.0-dev-paired6";
    public const string NumericVersion = "0.8.0.6";
    public const string MainTitle = "DIANA 0.8.0-dev-paired6 · PC 문서 작업";
    public const string SettingsTitle = "DIANA 0.8.0-dev-paired6 · PC 연결 설정";
    public const string DemoSettingsTitle = "DIANA 0.8.0-dev-paired6 · 가상 체험 설정";
    public const string PickerTitle = "DIANA 0.8.0-dev-paired6 · PC 문서 폴더 허용";
} }
